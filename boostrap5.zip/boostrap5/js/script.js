console.log("hello world");
//var sirve para declarar
//let sirve para declarar

var a = 1;
var b = 2;
var R = a + b;
console.log("Resultado " + R);


var c = 10;
var d = 5;
var Re = c*d;
console.log("Resultado " + Re);

var e = Math. sqrt(1244);
console.log("Resultado raiz: " + e);

var raiz2=Math.trunc(e)
console.log("El resultado de la Raíz aproximada es: " + raiz2);

var k = 500000;
var j = 2;
var numerosPrimos = [];

for (; j < k; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log("Los numero primos hasta el 500.000 son: " + numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}


